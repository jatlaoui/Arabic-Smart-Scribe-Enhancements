
# Core module initialization
