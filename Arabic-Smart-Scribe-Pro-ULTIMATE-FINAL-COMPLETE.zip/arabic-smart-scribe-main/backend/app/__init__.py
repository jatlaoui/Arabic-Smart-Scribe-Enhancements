
# Backend app initialization
