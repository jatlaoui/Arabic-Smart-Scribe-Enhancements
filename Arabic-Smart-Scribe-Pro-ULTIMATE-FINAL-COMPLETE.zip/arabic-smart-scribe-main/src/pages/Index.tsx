
import React from 'react';
import { FluidShahidApp } from '@/components/FluidShahidApp';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <FluidShahidApp />
    </div>
  );
};

export default Index;
