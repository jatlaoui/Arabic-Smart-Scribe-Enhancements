
import React from 'react';
import { UnifiedWritingInterface } from '@/components/unified-writing/UnifiedWritingInterface';

const UnifiedWriting = () => {
  return <UnifiedWritingInterface />;
};

export default UnifiedWriting;
